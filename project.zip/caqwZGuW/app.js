class App {
  constructor() {
    console.log('app works!')  
  }  
}

new App();